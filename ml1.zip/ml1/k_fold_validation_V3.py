import logistic_regression as lr
import naiveBayes as nb
import numpy as np 
import pandas as pd 

def k_fold_validation(X, y, learning_rate, num_iterations, regularization=0, k=5):
    X_folds = np.array_split(X, k)
    y_folds = np.array_split(y, k)
    lr_accuracy = []
    nb_accuracy = []

    for i in range(k):
        X_train = X_folds.copy()
        X_test = X_folds[i]

        y_train = y_folds.copy()
        y_test = y_folds[i]

        del X_train[i]
        del y_train[i]
        
        X_train = np.concatenate(X_train)
        y_train = pd.concat(y_train, sort=False)
        
        lr_accuracy.append(__run_logistic_regression(X_train.copy(), y_train.copy(), X_test, y_test, learning_rate, num_iterations, regularization))
        nb_accuracy.append(__run_naive_bayes(X_train.copy(), y_train.copy(), X_test, y_test, regularization))
        #print("Logistic Regression Accuracy: " , sum(lr_accuracy) / len(lr_accuracy))
     
    
    return (sum(lr_accuracy)/len(lr_accuracy)),(sum(nb_accuracy) / len(nb_accuracy))
    

        
#     print("Naive Bayes Accuracy: " , sum(nb_accuracy) / len(nb_accuracy))
      
def __run_logistic_regression(X_train, y_train, X_test, y_test, learning_rate, num_iterations, regularization): 
    model = lr.LogisticRegressionModel()
    model.fit(X_train, y_train, learning_rate, num_iterations, regularization)
    y_pred = model.predict(X_test)
    return model.evaluate_acc(y_test, y_pred)

def __run_naive_bayes(X_train, y_train, X_test, y_test, regularization):
    model = nb.GaussianNaiveBayes()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    return model.evaluate_acc(y_test, y_pred)