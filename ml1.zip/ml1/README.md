logistic_regression.py uses number of iterations as termination policy
logistic_regression_V2.py uses gradient step treshhold as termination policy 

k_fold_validation_V2.py uses logistic_regression.py
k_fold_validation_V3.py logistic_regression_V2.py