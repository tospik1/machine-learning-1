import numpy as np
class GaussianNaiveBayes():
    def __init__(self):
        self.mean=None
        self.std=None
        self.priors=None
    def fit(self,X,y): #Trainig
        # X.shape = N x d ==>  351, 34 for ionosphere
        # Y.shape = N, ==> 351,- binary
        N,d = X.shape
        C = y.nunique()
        self.priors =y.value_counts(ascending = True)/len(y)
        #self.priors = self.priors/len(y)
        #positivePrior = numPositive/ len(y)
        #negativePrior = numPositive/ len(y)
        #self.priors = [negativePrior,positivePrior]
        self.mean = np.zeros((d,C))
        self.std = np.zeros((d,C))
        for c in range(C):
            self.mean[:,c] =X[y==c].mean()
            self.std[:,c]= X[y==c].std()
    def predict(self,X):#Forward pass ## 1)calculate the probability of a data point to belong a certain class  2)do it for all of the classes 3)pick the maximum
        #mean.shape d ,C
        #std.shape d, C
        #X.shape N, d
        N,d =X.shape
        d,C = self.mean.shape
        predictions = np.zeros((N,C))
        for c in range(C):
            likelihood = self.ComputeLikelihood(X,c)
            predictions[:,c]= self.priors[c]*likelihood.prod(axis =1 )# axis =1 column wise  output 351,1 mult axis =0 row wise mult 1, 33
        return np.argmax(predictions,axis=1)
    #argmax(axis=1)
    def ComputeLikelihood(self,X,c):
        return (1/np.sqrt(2*np.pi*self.std[:,c]))*np.exp(-((X-self.mean[:,c])**2)/(2*self.std[:,c]))
    def evaluate_acc(self,y,predictions):
        return np.equal(y,predictions).sum()/len(y)
from sklearn.naive_bayes import GaussianNB

# clf = GaussianNB()
# clf.fit(X_train, y_train)
# from sklearn.metrics import accuracy_score
# accuracy_score(y_train,clf.predict(X_train))
# accuracy_score(y_test,clf.predict(X_test))
# nb= GaussianNaiveBayes()
# nb.fit(X_train, y_train)
# accuracy_score(y_train,nb.predict(X_train))
# accuracy_score(y_test,nb.predict(X_test))

