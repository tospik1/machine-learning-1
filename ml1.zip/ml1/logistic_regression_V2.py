import math 
import numpy as np

class LogisticRegressionModel:
  def __init__(self):
    self.N = 0
    self.D = 0
    self.weights = np.random.rand(1, 1)

  # X --> N x D matrix with bias units
  # y --> N x 1 matrix 
  # learningRate
  # numIterations
  #
  # iterates over numIterations and changes the weights matrix to
  # optimize the cost function
  def fit(self, X, y, learningRate, numIterations, regularization):
    self.N = X.shape[0]
    self.D = X.shape[1]
    y = y.to_numpy().reshape(-1, 1)
    self.weights = np.random.rand(self.D, 1)
    cost_prev = 100
    
    cnt = 0
    while(abs(self.cost(X,y) - cost_prev) > 0.025):
       cnt += 1
       if cnt % 100 == 0:
            print(cnt)
       self.weights = self.weights - learningRate * self.__gradient(X, y, regularization)
       cost_prev = self.cost(X,y)

#     for i in range(numIterations):
#       self.weights = self.weights - learningRate * self.__gradient(X, y, regularization)
#       print(self.cost(X,y), abs(self.cost(X,y) - cost_prev))
# #       print(
#       cost_prev = self.cost(X,y)

  # X --> N x D matrix with bias units
  # 
  # @return N x 1 matrix with guessed binary class
  def predict(self, X):
    #return self.__sigmoid(X.dot(self.weights))
    return np.where(self.__sigmoid(X.dot(self.weights)) > 0.5, 1, 0)

  def evaluate_acc(self, y, predictions):
    y = y.to_numpy().reshape(-1, 1)
    return np.equal(y,predictions).sum()/len(y)

  # Private function that calculates the gradient
  def __gradient(self, X, y, regularization):
    pred = np.dot(X, self.weights)
    grad = (1 / self.N) * X.T.dot((self.__sigmoid(pred) - y))
    grad[1:] += regularization * self.weights[1:]
    return grad

  # Returns cost 
  def cost(self, X, y):
    z = np.dot(X, self.weights)
    y = y.reshape(-1, 1)
    J = -(1/self.N) * np.sum(y * np.log1p(self.__sigmoid(z)) + (1-y) * np.log1p(1 - self.__sigmoid(z)))
    return J

  # Private function that calculates the sigmoid function
  def __sigmoid(self, x):
    return 1 / (1 + np.exp(-x))
